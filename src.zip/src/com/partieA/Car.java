package com.partieA;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;

public class Car implements Observable{

	
	private boolean playing = true;
	private String name;
	private Pair<Double> position;
	private Pair<Double> speedVect;
	private double direction;
	private Me me;
	private TheRotation r;
	
	
	public Car (String name) {
		this.name = name;
		this.position = new Pair<>(0.0 , 0.0);
	}
	
	
	public void setRotation (double r) {
		this.direction = r;
		this.r.invalidated(this);
	}
	
	
	
	
	public boolean stillPlaying () {
		return this.playing;
	}
	
	public String getName() {
		return this.name;
	}

	public void setPosition(String string) {
		Pair<Double> p = Outils.splitCoord(string);
		System.err.println("j'ai des position : "+string);
		System.err.println("j'ai des position : "+p);
		this.setPosition( p );
	}
	
	public void setPosition(Pair<Double> pos) {
		
		this.position = pos;
		if (this.me == null) {
			System.out.println("me == nulll");
		}
		this.me.invalidated(this);
		this.r.invalidated(this);
	}
	
	public Pair<Double> getPosition() {
		return this.position;
	}
	
	public Pair<Double> getSpeed() {
		return this.speedVect;
	}
	
	public void setSpeed (Pair<Double> s) {
		this.speedVect= s;
	}
	

	public void newCarPosition () {
		double oldX = this.getPosition().getX();
		double oldY = this.getPosition().getY();

		double newX = Outils.stayInRangeX(oldX+this.speedVect.getX());
		double newY = Outils.stayInRangeY(oldY+this.speedVect.getY());
		
		this.setPosition(new Pair<Double> (newX,newY));
		this.me.invalidated(this);
	}
	
	
	public void impultion () {
		synchronized (this) {
			Pair<Double> push = new Pair<>(Outils.impulsion*Math.cos(this.direction),Outils.impulsion*Math.sin(this.direction) );
			Pair<Double> newpos = new Pair<>(this.speedVect.getX()+push.getX() , this.speedVect.getY()+push.getY());
			this.speedVect = newpos;
			double taille = Math.hypot(this.speedVect.getX(), this.speedVect.getY());
			if (taille > Outils.MAX_SPEED) {
				double theta = Outils.getThetaFromxy(this.speedVect.getY(), this.speedVect.getX());
				System.out.println("theta vaux de mon ancient vercteur vitesse : "+theta+" et speedVect : "+this.speedVect);
				double d1 = Math.cos(theta)*Outils.MAX_SPEED;
				double d2 = Math.sin(theta)*Outils.MAX_SPEED;
				System.out.println("d1 = "+d1+" d2 = "+d2);
				this.speedVect = new Pair<Double> (d1 , d2);
				System.out.println(d1*taille+" "+d2*taille);
			}
		}
	}

	public double getRotation_() {
		return this.direction;
	}


	@Override
	public void addListener(InvalidationListener listener) {
		if (listener instanceof TheRotation) {
			this.r = (TheRotation) listener;
		}else if (listener instanceof Me) {
			this.me = (Me) listener;
		}
	}


	@Override
	public void removeListener(InvalidationListener listener) {
		// TODO Auto-generated method stub
		
	}


	public void setPlaying(boolean b) {
		this.playing = false;
	}
	
}
