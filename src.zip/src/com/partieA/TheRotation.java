package com.partieA;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.scene.transform.Rotate;

public class TheRotation extends Rotate implements InvalidationListener {

	@Override
	public void invalidated(Observable observable) {
		synchronized (observable) {
			Car c = (Car) observable;
			this.setAngle(c.getRotation_()*180/Math.PI);
			this.setPivotX(c.getPosition().getX());
			this.setPivotY(c.getPosition().getY());
		}
	}
}
