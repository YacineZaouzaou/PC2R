package com.partieA;

import javafx.beans.value.ObservableValueBase;

public class Pair<T> {
	private T x;
	private T y;
	
	public Pair (T x, T y) {
		this.x = x;
		this.y = y;
	}
	
	public void setNewPos (T x, T y) {
		this.x = x;
		this.y = y;
	}
	
	public T getX () {
		return this.x;
	}
	
	public T getY () {
		return this.y;
	}

	
	@Override
	public String toString () {
		return "( "+this.x+" , "+this.y+" )";
	}

}
