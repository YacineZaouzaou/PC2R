package com.partieA;

import javafx.application.Application;

public class Play {
	public static void main (String ... args) {
		Application.launch(GUI.class, args);
	}
}
