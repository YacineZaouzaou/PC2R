package com.partieA;

import javafx.event.Event;
import javafx.event.EventTarget;
import javafx.event.EventType;

public class RestartEvent extends Event {

	public RestartEvent(Object arg0, EventTarget arg1, EventType<? extends Event> arg2) {
		super(arg0, arg1, arg2);
		// TODO Auto-generated constructor stub
	}

}
