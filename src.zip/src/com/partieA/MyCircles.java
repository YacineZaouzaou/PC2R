package com.partieA;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.scene.shape.Circle;

public class MyCircles extends Circle implements InvalidationListener {

	@Override
	public void invalidated(Observable observable) {
		synchronized (observable) {
			super.setCenterX(((Others) observable).getPosition().getX());
			super.setCenterY(((Others) observable).getPosition().getY());
		}
	}

}
