package com.partieA;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.transform.Scale;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class GUI extends Application implements InvalidationListener , Observer {

	protected Scene scene;
	protected Stage stage;
	
	protected Map <String , MyCircles> others;
	protected Game g;
	protected Me me;
	protected TheRotation ro;
	protected Group p;
	protected Car c;
	protected Arena a;
	protected MyCircles obj;
	protected Rectangle fin  = new Rectangle(-500, -500 , 1000 , 1000);
	protected boolean end;
	protected Scale scale;
	protected String name;


	
	
	
	private void replay () throws Exception{
		this.c = new Car(this.name);
		c.setSpeed(new Pair<Double>(2.5,4.0));
		this.a = new Arena (c , this);
		synchronized (this.g) {
			this.g.setCar(c);
			this.g.setArena(a);	
		}
		synchronized (this.c) {
			this.c.addListener(this.me);
			this.c.addListener(this.ro);
			c.setPosition(new Pair<Double> (2.5, -35.9));
		}	
		synchronized (this.c) {
			this.me.setX(this.c.getPosition().getX());
			this.me.setY(this.c.getPosition().getY());
		}
		this.setEnvironment();
	}
	
	protected Scale createScale () {
		Scale s = new Scale();
		s.setX(1.0);
		s.setY(-1.0);
		s.setPivotX(0.0);
		s.setPivotY(0.0);
		return s;
	}
	
	protected void initialisation (Stage s) throws InterruptedException {
		System.out.println("hello world 'je suis à start dans GUI si tu veux supp");
		this.name = this.getParameters().getRaw().get(1);
		this.c = new Car(this.name);
		end = false;
		c.setSpeed(new Pair<Double>(2.5, 4.0));
		this.a = new Arena (c, this);
		g = new Game(c , a,this , Integer.parseInt(this.getParameters().getRaw().get(0)));
		s.setWidth(Outils.width);
		s.setHeight(Outils.height+20);
		p = new Group();
		p.getTransforms().add(new Translate(Outils.width/2, Outils.height/2));
		scale = this.createScale();
		p.getTransforms().add(scale);
		scene = new Scene(p , s.getMaxWidth(), s.getHeight());
		s.setScene(scene);
		scene.setFill(Color.BLACK);
		s.show();
		Thread t = new Thread(g);
		t.start();
	}
	
	public void setEnvironment () throws Exception{
		this.others = new HashMap<>();
		obj = new MyCircles();
		obj.setRadius(5.0);
		obj.setStroke(Color.RED);
		obj.setFill(Color.ORANGE);
		p.getChildren().add(obj);
		synchronized (this.c) {
			this.me = new Me();
			this.c.addListener(this.me);
			this.ro = new TheRotation();
			this.c.addListener(this.ro);
			this.ro.setAngle(45);
			this.me.getTransforms().add(ro);
			this.c.addListener(obj);
			c.setPosition(new Pair<Double> (2.5, -35.9));
		}
		this.me.setWidth(15);
		this.me.setHeight(10);
		this.me.setFill(Color.WHITE);
		this.p.getChildren().add(me);
		synchronized (g) {
			g.notify();
		}
		synchronized (this) {
			wait();
		}
		synchronized (this.c) {
			this.me.setX(this.c.getPosition().getX());
			this.me.setY(this.c.getPosition().getY());
		}
	}
	
	
	protected void startgame() {
		ScheduledExecutorService i = Executors.newScheduledThreadPool(1);
		i.scheduleAtFixedRate(new Runnable() {	
			@Override
			public void run() {
				synchronized (c) {
					if (end) {
						Thread.currentThread().interrupt();
						i.shutdown();
					}
					c.newCarPosition();
				}
			}
		}, 0, Outils.refrech_tickrate, TimeUnit.MILLISECONDS);
	}
	
	@Override
	public void start(Stage s) throws Exception {
		this.stage = s;
		this.initialisation(s);	
		this.setEnvironment();
		this.startgame();		
		
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				switch (event.getCode()) {
				case UP : 
					c.setPosition(a.getObjectif());
					break;
				case SPACE: 
					c.impultion();
					break;
					
				case RIGHT : 
					c.setRotation(c.getRotation_()-0.1);
					break;
					
				case LEFT : 
					c.setRotation(c.getRotation_()+0.1);
					break;
				case H : 
					System.out.println("objectif à la position "+a.getObjectif());
					System.out.println("le cochoné à la posiution : "+obj.getCenterX()+" "+obj.getCenterY());
				default : 
					//System.out.println("hey "+c.getName()+" you pressed key : "+event.getCode());
					break;
				}
				
			}
		});
		
		s.setOnCloseRequest(new EventHandler<WindowEvent>() {
			public void handle (WindowEvent we) {
				closeIt();
			}
			
		});
	}
	
	public void closeIt () {
		synchronized (c) {
			c.setPlaying(false);
			System.out.println("je le met à faux ");
		}
		synchronized (g) {
			g.notify();
		}
		end = true;
		System.out.println("closed");
		this.stage.close();
	}

	
	public void thereIsAwinner () {
		this.p.getChildren().clear();
		this.fin.setFill(Color.BLUE);
		this.p.getChildren().add(this.fin);
		Text t = new Text();
		synchronized(this.a) {
			t.setText("tous à genou devant votre roi : "+this.a.getWinner());
		}
		t.setStroke(Color.RED);
		t.getTransforms().add(scale);
		t.setTextAlignment(TextAlignment.CENTER);
		this.p.getChildren().add(t);
		this.end = true;
		
	}
	
	public void reprend () throws Exception {
		this.p.getChildren().clear();
		this.end = false;
		this.replay();
		this.startgame();
		System.out.println("normaly game is started");
		
	}
	
	@Override
	public void invalidated(Observable observable) {
		// TODO not to do
	}

	@Override
	public void notifyme() {
		synchronized (this.a) {
			obj.setCenterX(this.a.getObjectif().getX());
			obj.setCenterY(this.a.getObjectif().getY());		
		}
	}


	public void setCar(Car car) {
		this.c = car;
	}
	
	public void setArena (Arena a ) {
		this.a = a;
	}

	public void notify_newPlayer(Others o) {
		MyCircles c = new MyCircles();
		c.setRadius(8);
		c.setCenterX(o.getPosition().getX());
		c.setCenterY(o.getPosition().getY());
		c.setFill(Color.AQUAMARINE);
		o.addListener(c);
		this.others.put(o.getName(),c);
		this.p.getChildren().add(c);		
	}

	public void getConcurents() {
		synchronized (this.a) {
			for (String s : this.a.getOthers().keySet()) {
				if (this.others.containsKey(s))
					continue;
				this.notify_newPlayer(this.a.getOthers().get(s));
			}
		}
		synchronized (this.g) {
			this.g.notify();	
		}
	}
	
	
	public void removePlayer (String name) {
		this.p.getChildren().remove(this.others.get(name));
		this.others.remove(name);
		Thread tempo = new Thread (new Runnable() {
			
			@Override
			public void run() {
				synchronized (GUI.this.a) {
					GUI.this.a.definitiveRemove(name);
				}
			}
		});
		
		tempo.start();
		
	}
	
	
	
	

}
