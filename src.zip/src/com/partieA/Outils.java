package com.partieA;	

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sun.javafx.scene.paint.GradientUtils.Point;

public class Outils {
	
	//const 
	public static final double width = 800;
	public static final double height = 600;
	public static final double velocity = 0.1;
	public static final long refrech_tickrate___ = 200;
	private static final long r = 2;
	/*don't look at that*/
	public static final long refrech_tickrate = (long) ((1.0/ (double)Outils.r)*1000); // 2.0
	public static final double impulsion = 3.0;
	private static final Pair<Double> centre  = new Pair<Double>(Outils.width/2, Outils.height/2);
	public static final double MAX_SPEED = 5;
	
	
	private static Pattern p_coord = Pattern.compile("X(-?[0-9][0-9]*\\.[0-9]?[0-9]*)Y(-?[0-9][0-9]*\\.[0-9]?[0-9]*)");
	

	
	public static Pair<Double> splitCoord (String s) {
		Matcher m_coord = Outils.p_coord.matcher(s);
		if (m_coord.matches())
			return new Pair<Double>(Double.parseDouble(m_coord.group(1)) ,Double.parseDouble( m_coord.group(2)));
		return null;
	}

	
//	on lui donne directement la position sans la modifier cette méthode le fait 
	public static double getThetaFromxy (double x, double y) {
		//System.out.println("atan "+Math.atan2(x, y)); 
		return Math.atan2(x, y);
	}
	
	public static Pair<Double> getxyFromTheta (double theta){
		return new Pair<Double> (Math.cos(theta) ,Math.sin(theta));
	}
	
	public static double stayInRangeX (double x) {
		return Outils.stayInRange(x , Outils.width/2);
	}
	
	public static double stayInRangeY (double y) {
		return Outils.stayInRange(y, Outils.height/2);
	}
	
	private static double stayInRange (double value, double range) {
		//System.out.println("range"+ range);
		double v = value;
		if (value > range)
			value = -range;
		if (value < -range)
			value = range;
		//System.out.println("value : "+value);
		return value;
	}
	
	
	
}
