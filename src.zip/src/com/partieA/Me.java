package com.partieA;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.scene.shape.Rectangle;

public class Me extends Rectangle implements InvalidationListener {

	@Override
	public void invalidated(Observable observable) {
		synchronized (observable){
			Car c = (Car) observable;
			if (c == null) {
				System.out.println("c == null");
			}
			if (c.getPosition() == null) {
				System.out.println("position == null");
			}
			if (c.getPosition().getX() == null) {
				System.out.println("getX == null");
			}
			this.setX(c.getPosition().getX());
			this.setY(c.getPosition().getY());
		}
	}
}
