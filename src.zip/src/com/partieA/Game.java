package com.partieA;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import javafx.application.Platform;


public class Game implements Runnable{

	protected Car car;
	protected int PORT;
	protected Arena arena;
	protected GUI g;
	protected boolean premiereconnexion = true;
	
	protected String objectif_cas; // lorsqu'on rentre au milieur d'une partie
	
	protected Socket s;
	protected InputStreamReader reader;
	protected BufferedReader br;
	protected DataOutputStream output;
	
	
	public Game ( Car c ,Arena a, GUI g , int port) {
		this.car = c;
		this.arena = a;
		this.g = g;
		this.PORT = port;
	}

	public void connect () {
		this.premiereconnexion = true;
		try {
			s = new Socket ("127.0.0.1" , this.PORT);
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			output = new DataOutputStream (s.getOutputStream());
			String reponse;
			output.writeBytes("CONNECT/"+this.car.getName()+"/\n");
			reponse = br.readLine();
			String []reponse_splited = reponse.split("/");
			switch (reponse_splited[0])
			{
			case "WELCOME" : 
				synchronized (this.arena) {
					this.arena.addScore(reponse_splited[2]);
				}
				if (reponse_splited[1].equals("jeu")) {
					this.objectif_cas = reponse_splited[3];
				}
				process_play();
				break;
			case "DENIED" : 
				System.out.println("connection refusé à cause du nom peut être !!");
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						
					}
				});
				break ; // pas sûr que ce soit que ça
			default : 
				System.err.println("réponse innatendus "+reponse+" vérifiez la version __peut être__ ;)");
			}
		}catch (Exception e) {
			synchronized (this.g) {
				this.g.notify();
			}
			e.printStackTrace();
		}
	}

	
	
	public void process_play () {
		String reponse;
		String [] reponse_splited;
		while (this.car.stillPlaying()) {
			reponse_splited = null;
			try {
				reponse = br.readLine();
//				System.out.println("dans le process play "+reponse);
				reponse_splited = reponse.split("/");
				switch (reponse_splited[0]) {
				
				case "NEWPLAYER" :
					synchronized (this.arena) {
						this.arena.newPlayer(reponse_splited[1]);
					}
					break;
				case "PLAYERLEFT" :
					System.out.println("a pleyer has left");
					synchronized (this.arena) {
						this.arena.removePlayer(reponse_splited[1]);
					}
					break;
				case "SESSION" :
//					System.out.println("nouvelle session"+reponse);
					if (!this.premiereconnexion) {
						Platform.runLater(new Runnable() {			
							@Override
							public void run() {
								try {
									g.reprend();
								}catch (Exception e) {
									e.printStackTrace();
								}
							}
						});
						synchronized (this) {
							wait();
						}
					}
					
//					System.err.println("je reçois ça comme valeur "+reponse_splited[1]+" de longueur "+reponse_splited[1].length());
					
					this.premiereconnexion = false;
					synchronized (this.arena) {
						this.arena.startSession(reponse_splited[1]);
						this.arena.addObjectif(reponse_splited[2]);
					}
					synchronized (this.g) {
						g.notify();
					}
					Platform.runLater(new Runnable() {
						
						@Override
						public void run() {
							g.getConcurents();
							
						}
					});
					synchronized (this) {
						wait();
					}
					break;
				case "WINNER" :
					System.out.println(reponse);
					synchronized (this.arena) {
						this.arena.setScore(reponse_splited[1]);
					}
					Platform.runLater(new Runnable() {
						@Override
						public void run() {
							g.thereIsAwinner();	
						}
					});
					break;
				case "TICK" :
					if (premiereconnexion) {
						synchronized (this.arena) {
							this.arena.startSession(reponse_splited[1]);
							this.arena.addObjectif(this.objectif_cas);
						}
						synchronized (this.g) {
							g.notify();	
						}
						Platform.runLater(new Runnable() {
							
							@Override
							public void run() {
								g.getConcurents();
								
							}
						});
						premiereconnexion = false;
					}else {
						synchronized (this.arena) {
							this.arena.newPositions(reponse_splited[1]);
							synchronized (this.car) {
								System.out.println("sending new coordinates");
								this.output.writeBytes("NEWPOS/X"+this.car.getPosition().getX()+"Y"+this.car.getPosition().getY()+"/\n");
							}
						}
					}
					break;
				case "NEWOBJ" :
					
					System.err.println("just received new coords");
					synchronized (this.arena) {
						this.arena.addObjectif(reponse_splited[1]);
						this.arena.addScore(reponse_splited[2]);
						
					}
					break;
				default :
				// pas que !!! un comortement à faire ___ se deconnecter peut être !
					System.err.println("réponse innatendus "+reponse+" vérifiez la version __je suis déjà connecté au fait__");
				}
			} catch (InterruptedException |IOException |NullPointerException e) {
				e.printStackTrace();
				break;
			}	
		}
		try {
			synchronized (this.car) {
				this.output.writeBytes("EXIT/"+this.car.getName()+"/\n");
			}
		}catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void setCar (Car c) {
		this.car = c;
	}
	
	public void setArena (Arena a) {
		this.arena = a;
	}
	
	

	@Override
	public void run() {
		this.connect();
	}

	public void sendNewCord(double cumul_rot, double cumul_impulss) {
		try {
			this.output.writeBytes("/NEWCOM/A"+cumul_rot+"T"+cumul_impulss+"/\n");
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

}
