package com.partieA;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;

public class Others implements Observable{
	private String name;
	private Pair<Double> position;
	private InvalidationListener myListener;
	private Pair<Double> vitesse;
	private Double poussee;
	
	public Others (String name) {
		this.name = name;
		this.position = new Pair<>(0.0,0.0);
		this.vitesse = new Pair<>(0.0 , 0.0);
		this.poussee = 0.0;
	}
	
	public void setPosition(double x , double y) {
		this.position.setNewPos(x, y);
		try {
			this.myListener.invalidated(this);
		}catch (NullPointerException e) {
			e.printStackTrace();
		}
	}
	
	public Pair<Double> getPosition () {
		return this.position;
	}

	@Override
	public void addListener(InvalidationListener listener) {
		this.myListener = listener;
		
	}
	
	public String getName () {
		return this.name;
	}

	@Override
	public void removeListener(InvalidationListener listener) {
		// TODO Auto-generated method stub
	}
	
	public double getPoussee() {
		return this.poussee;
	}
	
	public Pair<Double> getVitesse () {
		return this.vitesse;
	}
	
	
	public void setPoussee (Double v) {
		this.poussee = v;
	}
	
	public void setVitesse (double x, double y) {
		this.vitesse.setNewPos(x, y);
	}
	
}
