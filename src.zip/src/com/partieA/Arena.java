package com.partieA;

import java.util.HashMap;
import java.util.Map;

import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;

public class Arena implements Observable{
	
	
	private InvalidationListener gui;
	protected Map<String , Others> players;
	private Map<String , Integer> scors;
	protected Car car;
	private Pair<Double> objectif;
	
	
	public Arena (Car c , GUI g) {
		this.players = new HashMap<>();
		this.scors = new HashMap<String, Integer>();
		this.car = c;
		this.gui = g;
		
	}
	
	public void newPlayer (String string) {
		Others new_ = new Others (string);
		this.players.put(string , new_);
		Platform.runLater(new Runnable() {
			
			@Override
			public void run() {
				((GUI)gui).notify_newPlayer(new_);
			}
		});
	}
	
	
	private void newPosition(String string , String coord) {
		this.players.get(string).setPosition(Outils.splitCoord(coord).getX(), Outils.splitCoord(coord).getY());	
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				Arena.this.gui.invalidated(Arena.this);
			}
		});
	}
	
	
	public void definitiveRemove(String name) {
		this.players.remove(name);
		this.scors.remove(name);
		System.out.println("removed");
	}


	public void removePlayer(String string) {
		Platform.runLater(new Runnable() {	
			@Override
			public void run() {
				((GUI) Arena.this.gui).removePlayer(string); 
			}
		});
		
	}

	public void startSession(String string) {
		String [] coords = string.split("\\|");
		String [] coord;
		synchronized (this.car) {
			for (String s : coords) {
				coord = s.split(":");
				if (!coord[0].equals(this.car.getName())) {
					if (!this.players.containsKey(coord[0])) {
						this.players.put(coord[0], new Others(coord[0]));
					}
					this.players.get(coord[0]).getPosition().setNewPos(Outils.splitCoord(coord[1]).getX(),  Outils.splitCoord(coord[1]).getY());
					
				}else {
					this.car.setPosition(coord[1]);
				}
			}
		}
	}
	
	

	public void newPositions(String string) {
		String [] coords = string.split("\\|");
		String [] coord;
		for (String s : coords) {
			coord = s.split(":");
			if (coord[0].equals(this.car.getName())) {
				continue;
			}else {
				if (!this.players.containsKey(coord[0])) {
					this.newPlayer(string);
					try {
						synchronized (this) {
							wait();
						}
					}catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				this.players.get(coord[0]).setPosition(Outils.splitCoord(coord[1]).getX(), Outils.splitCoord(coord[1]).getY());
			}
		}
	}
	
	public Pair<Double> getObjectif () {
		return this.objectif;
	}

	public void addObjectif(String string) {
		this.objectif = Outils.splitCoord(string);
		System.err.println(string);
		System.err.println("je Change l'objectif");
		((GUI) this.gui).notifyme();	
	}

	public void setScore(String string) {
		String [] scors = string.split("\\|");
		String [] scor;
		for (String s : scors) {
			scor = s.split(":");
			if (! this.scors.containsKey(scor[0])) {
				// erreur normalement !!!
			}else {
				this.scors.put(scor[0] , Integer.parseInt(scor[1]));
			}
		}
	}
	
	public Map<String , Others> getOthers () {
		return this.players;
	}


	public void addScore(String string) {
		String [] scors = string.split("\\|");
		String [] scor ;
		for (String s : scors) {
			scor = s.split(":");
			if (this.scors.containsKey(scor[0])) {
				this.scors.replace(scor[0], Integer.parseInt(scor[1]));
			}else {
				this.scors.put(scor[0], Integer.parseInt(scor[1]));
			}
		}	
	}


	@Override
	public void addListener(InvalidationListener listener) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void removeListener(InvalidationListener listener) {
		// TODO Auto-generated method stub
		
	}


	public String getWinner() {
		int max = -1;
		String winner = null;
		for (String s : this.scors.keySet()) {
			if (this.scors.get(s) > max)
				winner = s;
		}
		return winner;
	}



}
