package com.partieA;

public interface Observer {
	public void notifyme();
}
