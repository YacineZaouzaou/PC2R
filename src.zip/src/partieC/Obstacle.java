package partieC;

import com.partieA.Pair;

import javafx.beans.InvalidationListener;

public class Obstacle{
	private String name;
	private Pair<Double> position;
	
	public Obstacle (String name) {
		this.name = name;
		this.position = new Pair<>(0.0,0.0);

	}
	
	public void setPosition(double x , double y) {
		this.position.setNewPos(x, y);

	}
	
	public Pair<Double> getPosition () {
		return this.position;
	}

	
	public String getName () {
		return this.name;
	}
	
}