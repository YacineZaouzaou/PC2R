package partieC;

import com.partieA.GUI;

import javafx.application.Application;

public class Play_partieC {


	public static void main (String ... args) {
		Application.launch(GUI_partieC.class, args);

	}
}
