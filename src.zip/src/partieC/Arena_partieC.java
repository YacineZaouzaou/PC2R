package partieC;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.partieA.Car;
import com.partieA.GUI;
import com.partieA.Others;
import com.partieA.Outils;
import com.partieA.Pair;

import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;

public class Arena_partieC implements Observable {

	private static Pattern vp_coord = Pattern.compile("X(-?[0-9][0-9]*\\.[0-9]*)Y(-?[0-9][0-9]*\\.[0-9]*)VX(-?[0-9][0-9]*\\.[0-9]*)VY(-?[0-9][0-9]*\\.[0-9]*)T(-?[0-9]+\\.?[0-9]*e?-?[0-9]*)");
	 
	protected List<Obstacle> obstacle;
	
	public Arena_partieC(Car c, GUI_partieC g) {
		this.car = c ;
		this.gui = g;
		this.scors = new HashMap<String, Integer>();
		this.players = new HashMap<String, Others>();
		this.obstacle = new ArrayList<>();
	}
	
	
	
	public Pair<Double> splitCoord (String s) {
		Matcher m_coord = vp_coord.matcher(s);
		if (m_coord.matches())
			return new Pair<Double>(Double.parseDouble(m_coord.group(1)) ,Double.parseDouble( m_coord.group(2)));
		return null;
	}
	
	public Pair<Double> splitVitesse (String s){
		Matcher m_coord = vp_coord.matcher(s);
		if (m_coord.matches())
			return new Pair<Double>(Double.parseDouble(m_coord.group(3)) ,Double.parseDouble( m_coord.group(4)));
		return null;
	}
	
	public Double splitPoussee (String s){
		Matcher m_coord = vp_coord.matcher(s);
		if (m_coord.matches())
			return Double.parseDouble( m_coord.group(5));
		return null;
	}
	
	
	public void setVPosition (String positions) {
		String [] vcoords = positions.split("\\|");
		String []vcoord = null;
		for (String s : vcoords) {
			vcoord = s.split(":");
			if (vcoord[0].equals(this.car.getName())) {
				continue;
			}else {
				if (!this.players.containsKey(vcoord[0])) {
					this.newPlayer(s);
					try {
						synchronized (this) {
							wait();
						}
					}catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				this.players.get(vcoord[0]).setPosition(this.splitCoord(vcoord[1]).getX(), this.splitCoord(vcoord[1]).getY());
				this.players.get(vcoord[0]).setVitesse(this.splitCoord(vcoord[1]).getX(), this.splitCoord(vcoord[1]).getY());
				this.players.get(vcoord[0]).setPoussee(this.splitPoussee(vcoord[1]));
			}
		}
	}
	
	private InvalidationListener gui;
	protected Map<String , Others> players;
	private Map<String , Integer> scors;
	protected Car car;
	private Pair<Double> objectif;

	public List<Obstacle> getObstacle(){
		return this.obstacle;
	}
	
	public void newPlayer (String string) {
		Others new_ = new Others (string);
		synchronized (this) {
			this.players.put(string , new_);
			this.scors.put(string, 0);
		}
		Platform.runLater(new Runnable() {
			
			@Override
			public void run() {
				((GUI_partieC)gui).notify_newPlayer(new_);
			}
		});
	}
	
	private void newPosition(String string , String coord) {
		this.players.get(string).setPosition(Outils.splitCoord(coord).getX(), Outils.splitCoord(coord).getY());	
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				Arena_partieC.this.gui.invalidated(Arena_partieC.this);
			}
		});
	}
	
	
	public void definitiveRemove(String name) {
		this.players.remove(name);
		this.scors.remove(name);
	}


	public void removePlayer(String string) {
		Platform.runLater(new Runnable() {	
			@Override
			public void run() {
				((GUI) Arena_partieC.this.gui).removePlayer(string); 
			}
		});
	}

	public void startSession(String string) {
		String [] coords = string.split("\\|");
		String [] coord;
		synchronized (this.car) {
			for (String s : coords) {
				coord = s.split(":");
				if (!coord[0].equals(this.car.getName())) {
					if (!this.players.containsKey(coord[0])) {
						this.players.put(coord[0], new Others(coord[0]));
					}
					this.players.get(coord[0]).getPosition().setNewPos(Outils.splitCoord(coord[1]).getX(),  Outils.splitCoord(coord[1]).getY());
					
				}else {
					this.car.setPosition(Outils.splitCoord(coord[1]));
				}
			}
		}
	}
	
	public void newSessionTick (String string ) {
		String [] coords = string.split("\\|");
		String [] coord;
		synchronized (this.car) {
			for (String s : coords) {
				coord = s.split(":");
				if (!coord[0].equals(this.car.getName())) {
					if (!this.players.containsKey(coord[0])) {
						this.players.put(coord[0], new Others(coord[0]));
					}
					this.players.get(coord[0]).getPosition().setNewPos(this.splitCoord(coord[1]).getX(),  this.splitCoord(coord[1]).getY());
					
				}else {
					this.car.setPosition(this.splitCoord(coord[1]));
				}
			}
		}
	}
	

	public void newPositions(String string) {
		String [] coords = string.split("\\|");
		String [] coord;
		for (String s : coords) {
			coord = s.split(":");
			System.out.println(coord[1]);
			if (coord[0].equals(this.car.getName())) {
				synchronized (this.car) {
					this.car.setPosition(this.splitCoord(coord[1]));
					this.car.setSpeed(this.splitVitesse(coord[1]));
					this.car.setRotation(this.splitPoussee(coord[1]));
				}
			}else {
				if (!this.players.containsKey(coord[0])) {
					this.newPlayer(string);
					try {
						synchronized (this) {
							wait();
						}
					}catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				this.players.get(coord[0]).setPosition(this.splitCoord(coord[1]).getX(), this.splitCoord(coord[1]).getY());
				try {
					System.out.println("dans le try de newPos");
					this.players.get(coord[0]).setVitesse(this.splitVitesse(coord[1]).getX(), this.splitVitesse(coord[1]).getY());
					this.players.get(coord[0]).setPoussee(this.splitPoussee(coord[1]));
				}catch (ArrayIndexOutOfBoundsException e) {
					System.out.println("premiere connection tombe sur un tick");
				}
			}
		}
	}
	
	public Pair<Double> getObjectif () {
		return this.objectif;
	}

	public void addObjectif(String string) {
		this.objectif = Outils.splitCoord(string);
		((GUI_partieC) this.gui).notifyme();	
	}

	public void setScore(String string) {
		String [] scors = string.split("\\|");
		String [] scor;
		for (String s : scors) {
			scor = s.split(":");
			if (! this.scors.containsKey(scor[0])) {
			}else {
				this.scors.put(scor[0] , Integer.parseInt(scor[1]));
			}
		}
	}
	
	public Map<String , Others> getOthers () {
		return this.players;
	}


	public void addScore(String string) {
		String [] scors = string.split("\\|");
		String [] scor ;
		for (String s : scors) {
			scor = s.split(":");
			if (this.scors.containsKey(scor[0])) {
				this.scors.replace(scor[0], Integer.parseInt(scor[1]));
			}else {
				this.scors.put(scor[0], Integer.parseInt(scor[1]));
			}
		}	
		System.out.println(this.scors);
	}


	@Override
	public void addListener(InvalidationListener listener) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void removeListener(InvalidationListener listener) {
		// TODO Auto-generated method stub
		
	}


	public String getWinner() {
		int max = -1;
		String winner = null;
		for (String s : this.scors.keySet()) {
			if (this.scors.get(s) > max) {
				max = this.scors.get(s);
				winner = s;
			}
		}
		return winner;
	}



	public void addObstacl(String string) {
		String [] coords = string.split("\\|");
		Pair<Double> coord;
		for (String s : coords) {
			Obstacle nouveau = new Obstacle ("obstacle");
			coord = Outils.splitCoord(s);
			nouveau.setPosition(coord.getX(), coord.getY());
			this.obstacle.add(nouveau);
		}
	}



	public void addScore_withWinner(String string) {
		this.addScore(string);

		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				((GUI_partieC)gui).thereIsAwinner();	
			}
		});
		
	}
}
