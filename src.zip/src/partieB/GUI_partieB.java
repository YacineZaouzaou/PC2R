package partieB;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.partieA.Car;
import com.partieA.GUI;
import com.partieA.Me;
import com.partieA.MyCircles;
import com.partieA.Observer;
import com.partieA.Others;
import com.partieA.Outils;
import com.partieA.Pair;
import com.partieA.TheRotation;

import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.transform.Scale;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class GUI_partieB extends Application implements InvalidationListener , Observer{
	
	protected Scene scene;
	protected Stage stage;
	protected Map <String , MyCircles> others;
	protected Game_partieB g;
	protected Me me;
	protected TheRotation ro;
	protected Group p;
	protected Car c;
	protected Arena_partieB a;
	protected MyCircles obj;
	protected Rectangle fin  = new Rectangle(-500, -500 , 1000 , 1000);
	protected boolean end;
	protected Scale scale;
	protected String name;

	private void replay () throws Exception{
		this.c = new Car(this.name);
		c.setSpeed(new Pair<Double>(2.5,4.0));
		this.a = new Arena_partieB (c , this);
		synchronized (this.g) {
			this.g.setCar(c);
			this.g.setArena(a);	
		}
		this.setEnvironment();
	}
	
	protected Scale createScale () {
		Scale s = new Scale();
		s.setX(1.0);
		s.setY(-1.0);
		s.setPivotX(0.0);
		s.setPivotY(0.0);
		return s;
	}
	
	 
	protected void startgame() {
		ScheduledExecutorService i = Executors.newScheduledThreadPool(1);
		i.scheduleAtFixedRate(new Runnable() {	
			@Override
			public void run() {
				synchronized (GUI_partieB.this.c) {
					if (end) {
						Thread.currentThread().interrupt();
						i.shutdown();
					}
					synchronized (GUI_partieB.this.g) {
						synchronized (GUI_partieB.this) {
							GUI_partieB.this.g.sendNewCord (GUI_partieB.this.cumul_rot,GUI_partieB.this.cumul_impulss );
							System.out.println("nombre de concurent : "+GUI_partieB.this.others.size());
							System.out.println("je suis toujours là : "+(GUI_partieB.this.me != null));
							System.out.println("le nombre d'enfant de p : "+GUI_partieB.this.p.getChildren().size());
							System.out.println("my positions : "+GUI_partieB.this.c.getPosition());
						}
					}
				}
			}
		}, 0, Outils.refrech_tickrate___, TimeUnit.MILLISECONDS);
	}
	
	public void setEnvironment () throws Exception{
		this.others = new HashMap<>();
		obj = new MyCircles();
		obj.setRadius(5.0);
		obj.setStroke(Color.RED);
		obj.setFill(Color.ORANGE);
		p.getChildren().add(obj);
		synchronized (this.c) {
			this.me = new Me();
			this.c.addListener(this.me);
			this.ro = new TheRotation();
			this.c.addListener(this.ro);
			this.ro.setAngle(45);
			this.me.getTransforms().add(ro);
			this.c.addListener(obj);
			c.setPosition(new Pair<Double> (2.5, -35.9));
		}
		this.me.setWidth(15);
		this.me.setHeight(10);
		this.me.setFill(Color.WHITE);
		this.p.getChildren().add(me);
		synchronized (g) {
			g.notify();
		}
		synchronized (this) {
			wait();
		}
		this.getConcurents();
		synchronized (this.c) {
			this.me.setX(this.c.getPosition().getX());
			this.me.setY(this.c.getPosition().getY());
		}
	}
	
	
	public double getCumul_rot() {
		return cumul_rot;
	}

	public void setCumul_rot(double cumul_rot) {
		this.cumul_rot = cumul_rot;
	}

	public double getCumul_impulss() {
		return cumul_impulss;
	}

	public void setCumul_impulss(double cumul_impulss) {
		this.cumul_impulss = cumul_impulss;
	}

	protected double cumul_rot;
	protected double cumul_impulss;
	
	protected void initialisation (Stage s) throws InterruptedException {
		this.name = this.getParameters().getRaw().get(1);
		this.c = new Car(this.name);
		end = false;
		c.setSpeed(new Pair<Double>(2.5, 4.0));
		this.a = new Arena_partieB (c, this);
		g = new Game_partieB(c , a,this , Integer.parseInt(this.getParameters().getRaw().get(0)));
		s.setWidth(Outils.width);
		s.setHeight(Outils.height+20);
		p = new Group();
		p.getTransforms().add(new Translate(Outils.width/2, Outils.height/2));
		scale = this.createScale();
		p.getTransforms().add(scale);
		scene = new Scene(p , s.getMaxWidth(), s.getHeight());
		s.setScene(scene);
		scene.setFill(Color.BLACK);
		s.show();
		Thread t = new Thread(g);
		t.setDaemon(true);
		t.start();
	}
	
	
	public void start(Stage s) throws Exception {
		this.stage = s;
		this.initialisation(s);	
		this.setEnvironment();
		this.startgame();	
		Thread.currentThread().setDaemon(true);
		
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				switch (event.getCode()) {
				case UP : 
					c.setPosition(a.getObjectif());
					break;
				case SPACE: 
					cumul_impulss += Outils.impulsion;
					break;
					
				case RIGHT :
					cumul_rot -= 0.1;
					break;
					
				case LEFT :
					cumul_rot += 0.1;
					break;
				case H : 
					System.out.println("objectif à la position "+a.getObjectif());
					System.out.println("le cochoné à la posiution : "+obj.getCenterX()+" "+obj.getCenterY());
				default : 
					break;
				}
				
			}
		});
		
		s.setOnCloseRequest(new EventHandler<WindowEvent>() {
			public void handle (WindowEvent we) {
				closeIt();
			}
			
		});
	}
	
	
	public void closeIt () {
		synchronized (c) {
			c.setPlaying(false);
		}
		synchronized (g) {
			g.notify();
		}
		end = true;
		System.out.println("closed");
		this.stage.close();
	}

	
	public void thereIsAwinner () {
		this.p.getChildren().clear();
		this.fin.setFill(Color.BLUE);
		this.p.getChildren().add(this.fin);
		Text t = new Text();
		synchronized(this.a) {
			t.setText("tous à genou devant votre roi : "+this.a.getWinner());
		}
		t.setStroke(Color.RED);
		t.getTransforms().add(scale);
		t.setTextAlignment(TextAlignment.CENTER);
		this.p.getChildren().add(t);
		this.end = true;
		
	}
	
	public void reprend () throws Exception {
		this.p.getChildren().clear();
		this.end = false;
		this.replay();
		this.startgame();
		
	}
	
	@Override
	public void invalidated(Observable observable) {
		// TODO not to do
	}

	@Override
	public void notifyme() {
		synchronized (this.a) {
			obj.setCenterX(this.a.getObjectif().getX());
			obj.setCenterY(this.a.getObjectif().getY());		
		}
	}


	public void setCar(Car car) {
		this.c = car;
	}
	
	public void setArena (Arena_partieB a ) {
		this.a = a;
	}

	public void notify_newPlayer(Others o) {
		MyCircles c = new MyCircles();
		c.setRadius(8);
		c.setCenterX(o.getPosition().getX());
		c.setCenterY(o.getPosition().getY());
		c.setFill(Color.AQUAMARINE);
		o.addListener(c);
		this.others.put(o.getName(),c);
		this.p.getChildren().add(c);		
	}

	public void getConcurents() {
		synchronized (this.a) {
			for (String s : this.a.getOthers().keySet()) {
				if (this.others.containsKey(s))
					continue;
				this.notify_newPlayer(this.a.getOthers().get(s));
			}
		}
		synchronized (this.g) {
			this.g.notify();	
		}
	}
	
	
	public void removePlayer (String name) {
		this.p.getChildren().remove(this.others.get(name));
		this.others.remove(name);
		Thread tempo = new Thread (new Runnable() {
			
			@Override
			public void run() {
				synchronized (GUI_partieB.this.a) {
					GUI_partieB.this.a.definitiveRemove(name);
				}
			}
		});
		
		tempo.start();
		
	}
}
