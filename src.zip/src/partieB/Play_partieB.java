package partieB;

import com.partieA.GUI;

import javafx.application.Application;

public class Play_partieB {


	public static void main (String ... args) {
		Application.launch(GUI_partieB.class, args);

	}
}
